import { jest } from "@jest/globals";

global.jest = jest;
