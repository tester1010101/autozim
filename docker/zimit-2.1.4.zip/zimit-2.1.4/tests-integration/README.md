These are integration tests, meant to be ran inside the CI (because we need to first perform a zimit run on a given website and then check its output)
