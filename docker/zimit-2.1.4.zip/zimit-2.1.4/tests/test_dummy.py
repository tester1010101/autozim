from zimit.zimit import NORMAL_WARC2ZIM_EXIT_CODE


# dummy test, just to have coverage report done
def test_something_exists():
    assert NORMAL_WARC2ZIM_EXIT_CODE
